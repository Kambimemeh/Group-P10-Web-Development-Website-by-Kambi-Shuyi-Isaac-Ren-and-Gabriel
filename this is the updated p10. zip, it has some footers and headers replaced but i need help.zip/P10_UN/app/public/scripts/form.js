fetch("form.json")
    .then(response => response.json())
    .then(data => {

         const footerData = data.footer;
         const footer = document.getElementById(footerData.id);

            footer.innerHTML = "";

            const ul = document.createElement("ul");
            footerData.links.forEach(item => {
              const li = document.createElement("li");
              const a = document.createElement("a");
              a.href = item.href;
             a.textContent = item.label;
             li.appendChild(a);
              ul.appendChild(li);
          });

         const p = document.createElement("p");
         p.textContent = footerData.note;

         footer.appendChild(ul);
         footer.appendChild(p);






        

        const navbar = document.getElementById('navbar');

        navbar.innerHTML = "";

        data.navbar.forEach(item => {
            const li = document.createElement("li");
            if (item.active) li.classList.add("active");

            const a = document.createElement("a");
            a.href = item.href;
            a.textContent = item.label;
            li.appendChild(a);
            navbar.appendChild(li);
        })

        const section = document.getElementById(data.section.id);

        const form = document.createElement('form');
        form.id = data.section.form.id;
        form.method = data.section.form.method;
        form.action = data.section.form.action;
        section.appendChild(form);

        const fieldset = document.createElement('fieldset');

        const legend = document.createElement('legend');
        legend.textContent = data.section.form.fieldset.legend;
        fieldset.appendChild(legend);

        data.section.form.fieldset.fields.forEach(field => {
            const label = document.createElement('label');
            label.setAttribute('for', field.id);
            label.textContent = field.label;

            const input = document.createElement('input');
            input.type = field.type;
            input.id = field.id;
            input.name = field.name;
            if (field.required) input.required = true;

            fieldset.appendChild(label);
            fieldset.appendChild(input);
            fieldset.appendChild(document.createElement('br'));
            fieldset.appendChild(document.createElement('br'));
        });

        const submit = document.createElement('input');
        submit.type = data.section.form.fieldset.submit.type;
        submit.value = data.section.form.fieldset.submit.value;
        fieldset.appendChild(submit);


        form.appendChild(fieldset);
        form.appendChiled(form)

       


    });