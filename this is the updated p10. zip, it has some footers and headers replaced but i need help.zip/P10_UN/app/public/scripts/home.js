fetch("home.json")
  .then(response => response.json())
  .then(data => {
    const Banner = document.querySelector("#home .banner");
    Banner.innerHTML = `<img src="${data.banner.imageURL}" alt="${data.banner.alt}">`;

    const LeftSides = document.querySelectorAll("#navSection .left");
    const RightSide = document.querySelector("#navSection .right");

    LeftSides[0].innerHTML = `<h2>${data.goals[0].goalname}</h2> <a href="${data.goals[0].linkURL}" target="_blank"><img src="${data.goals[0].imageURL}" alt="${data.goals[0].alt}"></a>`;

    RightSide.innerHTML = `<h2>${data.goals[1].goalname}</h2><a href="${data.goals[1].linkURL}" target="_blank"> <img src="${data.goals[1].imageURL}" alt="${data.goals[1].alt}"></a>`;

    LeftSides[1].innerHTML = `<h2>${data.goals[2].goalname}</h2><a href="${data.goals[2].linkURL}" target="_blank">  <img src="${data.goals[2].imageURL}" alt="${data.goals[2].alt}"> </a>`;
    


    const navbar = document.getElementById('navbar');

        navbar.innerHTML = "";

        data.navbar.forEach(item => {
            const li = document.createElement("li");
            if (item.active) li.classList.add("active");

            const a = document.createElement("a");
            a.href = item.href;
            a.textContent = item.label;
            li.appendChild(a);
            navbar.appendChild(li);
        })
  })
  .catch(error => console.error("Error loading JSON:", error));


  