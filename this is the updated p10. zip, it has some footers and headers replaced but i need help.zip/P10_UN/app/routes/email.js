const express = require("express");
const sendEmail = require("../services/mailer");

const router = express.Router();

router.post("/send-email", async (req, res) => {
  const { email, firstName,lastName, message } = req.body;

  try {
    const subject = "Welcome to Our Newsletter";
    const body = `Hello ${firstName} ${lastName},\n\nThank you for subscribing to our newsletter!\n\nYour message: ${message}`;

    const info = await sendEmail(email, subject, body);
    res.redirect("/sent.html");
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;