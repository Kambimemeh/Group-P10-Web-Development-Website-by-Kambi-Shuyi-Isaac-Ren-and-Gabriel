
let myTeam = document.querySelector('#team');

if (document.querySelector("#team")) {
    let localJsonFile = "team.json";
    
    document.addEventListener('DOMContentLoaded', ()=>{
        fetch(localJsonFile)
        .then(response => response.json())
        .then (responseData =>{ console.log(responseData);
            for (item of responseData){
                
                const team = document.createElement('article');
                myTeam.appendChild(team)
                
                const heading = document.createElement('h4');
                heading.textContent =`${item.Name}`;
                team.appendChild(heading)
                
                const role = document.createElement('p');
                role.textContent = `${item.Role}`
                team.appendChild(role)
                
                const email = document.createElement('p');
                email.textContent = `${item.Email}`
                team.appendChild(email)

                team.setAttribute('class', 'team');
            }
        })
        .catch(error => console.error("Error fetching JSON data:", error));
    })
}