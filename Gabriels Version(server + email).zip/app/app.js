const express = require("express");
const path = require("path");
const emailRoutes = require("./routes/email");



const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use("/", emailRoutes);

app.get("/", (req, res) => {
res.sendFile('index.html', (err)=>{
if (err)
console.log(err);
});
});



app.listen(port, () => {
console.log(`myapp is listening on port ${port}!`);
});

