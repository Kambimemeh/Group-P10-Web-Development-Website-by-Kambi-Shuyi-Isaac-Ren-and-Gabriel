const nodemailer = require("nodemailer");

async function sendEmail(to, subject, message) {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "gabrielattfield@gmail.com",
      pass: "dudv dvmy ykcc lfmp" 
    }
  });

  return transporter.sendMail({
    from: '"Gabriel" <zuu25mgu@uea.ac.uk>',
    to: to,
    subject: subject,
    text: message 
  });
}

module.exports = sendEmail;